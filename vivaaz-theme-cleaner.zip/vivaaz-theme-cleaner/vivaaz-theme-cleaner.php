<?php
/**
 * Plugin Name: Vivaaz Theme Cleanup Utility
 * Description: One-click utility to safely delete stuck or locked theme directories on InfinityFree / shared hosts.
 * Version: 1.1.0
 * Author: Vivaaz Gems
 */

if (!defined('ABSPATH')) exit;

function vivaaz_clean_stuck_themes() {
    $targets = array(
        WP_CONTENT_DIR . '/themes/flatsome-child',
        WP_CONTENT_DIR . '/themes/vivaazgems-theme-standalone'
    );
    
    function vivaaz_force_rmdir($dir) {
        if (!is_dir($dir)) return;
        @chmod($dir, 0777);
        $items = @scandir($dir);
        if (!$items) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                vivaaz_force_rmdir($path);
            } else {
                @chmod($path, 0777);
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    foreach ($targets as $target) {
        if (is_dir($target)) {
            vivaaz_force_rmdir($target);
        }
    }
}
register_activation_hook(__FILE__, 'vivaaz_clean_stuck_themes');
add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible"><p><strong>Vivaaz Cleaner:</strong> The stuck old theme folders have been cleaned up! You can now upload your new theme zip.</p></div>';
});
