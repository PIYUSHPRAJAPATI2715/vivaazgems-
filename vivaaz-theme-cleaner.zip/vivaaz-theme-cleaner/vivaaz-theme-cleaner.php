<?php
/**
 * Plugin Name: Vivaaz Theme Cleanup Utility
 * Description: One-click utility to safely delete stuck or locked theme directories on InfinityFree / shared hosts.
 * Version: 1.0.0
 * Author: Vivaaz Gems
 */

if (!defined('ABSPATH')) exit;

function vivaaz_clean_stuck_themes() {
    $targets = array(
        WP_CONTENT_DIR . '/themes/vivaazgems-theme-standalone'
    );
    
    function vivaaz_force_rmdir($dir) {
        if (!is_dir($dir)) return;
        @chmod($dir, 0777);
        $items = @scandir($dir);
        if (!$items) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                vivaaz_force_rmdir($path);
            } else {
                @chmod($path, 0777);
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    $cleaned = array();
    foreach ($targets as $target) {
        if (is_dir($target)) {
            vivaaz_force_rmdir($target);
            if (!is_dir($target)) {
                $cleaned[] = basename($target);
            }
        }
    }
}
register_activation_hook(__FILE__, 'vivaaz_clean_stuck_themes');
add_action('admin_notices', function() {
    $dir = WP_CONTENT_DIR . '/themes/vivaazgems-theme-standalone';
    if (!is_dir($dir)) {
        echo '<div class="notice notice-success is-dismissible"><p><strong>Vivaaz Cleaner:</strong> The stuck old theme folder has been successfully removed! You can now safely upload your new theme.</p></div>';
    }
});
